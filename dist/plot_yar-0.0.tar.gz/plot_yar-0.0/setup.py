from setuptools import setup

setup(name='plot_yar',
      version='0.0',
      description='Plotting_graphs',
      packages=['plot_yar'],
      author_email='vodyar00@mail.ru',
      zip_safe=False)